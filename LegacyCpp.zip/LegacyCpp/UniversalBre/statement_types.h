#pragma once

namespace core
{
    enum class statement_type
    {
        assignment_statement,
        function_assignment_statement
    };
}
