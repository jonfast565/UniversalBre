#pragma once

#include "global_defines.h"

namespace core {
    class control_flow_node
    {
    public:
        control_flow_node();
        ~control_flow_node();
    };
    ALIAS_TYPES(control_flow_node)
}

