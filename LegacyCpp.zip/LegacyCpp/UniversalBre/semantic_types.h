#pragma once

namespace core
{
    enum class assignment_type
    {
        variable_assignment,
        function_assignment
    };
}
