#include "control_flow_node.h"



core::control_flow_node::control_flow_node()
{
}


core::control_flow_node::~control_flow_node()
{
}
