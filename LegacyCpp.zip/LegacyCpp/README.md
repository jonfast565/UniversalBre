# UniversalBre
A business rules language with a convenient interpreter
